import * as Home from "./Home";
import * as Jobs from "./Jobs";
import * as Candidates from "./Candidates";
export { Home,Jobs,Candidates };