import styles from './Jobs.module.scss';
import * as components from '../../components';
import axios from 'axios';
import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import JobsKanban from './JobsKanban';

const Jobs = () => {
    const [jobs, setJobs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");
    const [view, setView] = useState('list'); // 'list' or 'kanban'

    useEffect(() => {
        async function fetchJobs() {
            try {
                const res = await axios.get('/api/jobs');
                setJobs(res.data.jobs);
            } catch (error) {
                console.error("Failed to fetch jobs:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchJobs();
    }, []);

    const filteredJobs = useMemo(() => {
        return jobs.filter(j => {
            // Assuming you have fixed the inconsistent data field name issue
            const jobTitle = j.name || j.title;
            const matchesSearch = jobTitle.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesStatus = statusFilter === 'all' || j.status === statusFilter;
            return matchesSearch && matchesStatus;
        });
    }, [jobs, searchQuery, statusFilter]);

    // Define the handler functions
    const handleEdit = (jobId) => {
        // You can add your logic for editing a job here
        // For example, opening a modal or navigating to an edit page
        console.log(`Edit button clicked for job ID: ${jobId}`);
    };

    const handleArchive = (jobId) => {
        // You can add your logic for archiving/unarchiving a job here
        // For example, making an API call to update the job status
        const job = jobs.find(j => j.id === jobId);
        if (job) {
            const newStatus = job.status === 'Open' ? 'Archived' : 'Open';
            console.log(`Toggling status for job ID: ${jobId} to ${newStatus}`);
            // Here you would typically make an API call to update the status in the backend
            // and then update the state locally.
            setJobs(jobs.map(j => j.id === jobId ? { ...j, status: newStatus } : j));
        }
    };


    const { Card } = components.Jobs;

    return (
        <div className={styles.Jobs}>
            <h1 className={styles.h1}>Jobs</h1>

            <div className={styles.controls}>
                <input
                    type="text"
                    placeholder="Search by title..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                    <option value="all">All Statuses</option>
                    <option value="open">Open</option>
                    <option value="closed">Closed</option>
                    <option value="on_hold">On Hold</option>
                    <option value="Archived">Archived</option>
                </select>
                <button onClick={() => setView(view === 'list' ? 'kanban' : 'list')}>
                    Switch to {view === 'list' ? 'Kanban' : 'List'} View
                </button>
            </div>

            {loading && <h1>Loading Jobs...</h1>}

            {view === 'list' && !loading && (
                <div className={styles.container}>
                    {filteredJobs.map(job => (
                        <Card
                            key={job.id}
                            id={job.id}
                            name={job.name || job.title} // Handle both name/title
                            mode={job.mode}
                            type={job.type}
                            exp={job.experience}
                            status={job.status}
                            // Pass the handler functions as props
                            onEdit={() => handleEdit(job.id)}
                            onArchive={() => handleArchive(job.id)}
                        />
                    ))}
                </div>
            )}

            {view === 'kanban' && !loading && (
                <JobsKanban jobs={filteredJobs} setJobs={setJobs} />
            )}
        </div>
    );
}

export default Jobs;