import styles from './Candidates.module.scss';
import * as components from '../../components';
import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { FixedSizeList as List } from 'react-window';
import CandidatesKanban from './CandidatesKanban';
// You will create this component next
// import CandidatesKanban from './CandidatesKanban'; 

const Candidates = () => {
    const [candidates, setCandidates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");
    const [stageFilter, setStageFilter] = useState("all");
    const [view, setView] = useState('list'); // 'list' or 'kanban'

    useEffect(() => {
        async function fetchCandidates() {
            try {
                const res = await axios.get('/api/candidates');
                setCandidates(res.data.candidates);
            } catch (error) {
                console.error("Failed to fetch candidates:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchCandidates();
    }, []);

    const filteredCandidates = useMemo(() => {
        return candidates.filter(c => {
            const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.email.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesStage = stageFilter === 'all' || c.stage === stageFilter;
            return matchesSearch && matchesStage;
        });
    }, [candidates, searchQuery, stageFilter]);


    const { Card } = components.Candidates;

    const CandidateRow = ({ index, style }) => {
        const candidate = filteredCandidates[index];
        return (
            <div style={style} className={styles.candidateRow}>
                <Link to={`/candidates/${candidate.id}`}>
                    <Card key={candidate.id} name={candidate.name} email={candidate.email} />
                </Link>
            </div>
        );
    };

    return (
        <div className={styles.Candidates}>
            <h1 className={styles.h1}>Candidates</h1>

            <div className={styles.controls}>
                <input
                    type="text"
                    placeholder="Search by name or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                <select value={stageFilter} onChange={(e) => setStageFilter(e.target.value)}>
                    <option value="all">All Stages</option>
                    <option value="applied">Applied</option>
                    <option value="screen">Screen</option>
                    <option value="tech">Tech</option>
                    <option value="offer">Offer</option>
                    <option value="hired">Hired</option>
                    <option value="rejected">Rejected</option>
                </select>
                <button onClick={() => setView(view === 'list' ? 'kanban' : 'list')}>
                    Switch to {view === 'list' ? 'Kanban' : 'List'} View
                </button>
            </div>

            {loading && <h1>Loading Candidates...</h1>}

            {view === 'list' && !loading && (
                 <div className={styles.container}>
                    <List
                        height={600}
                        itemCount={filteredCandidates.length}
                        itemSize={80} // Height of each row
                        width="100%"
                    >
                        {CandidateRow}
                    </List>
                </div>
            )}
            
            {view === 'kanban' && !loading && (
                <CandidatesKanban candidates={filteredCandidates} setCandidates={setCandidates} />
            )}
        </div>
    );
}
export default Candidates;